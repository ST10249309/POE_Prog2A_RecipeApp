﻿using System;
using System.Collections.Generic;
using System.Linq;

public delegate void CalorieNotificationHandler(string message);

public class Recipe
{
    public List<string> Name { get; private set; } = new List<string>();
    public List<Ingredient> Ingredients { get; private set; } = new List<Ingredient>();
    public List<string> Steps { get; private set; } = new List<string>();
    public event CalorieNotificationHandler? CalorieNotification;

    public void EnterRecipe()
    {
        Console.WriteLine(new string('-', 30)); // Line at the top of the recipe entry
        Console.WriteLine("\nEnter recipe details:");

        Console.Write("Recipe name: ");
        Name.Clear();
        Name.Add(Console.ReadLine() ?? "");

        Console.Write("Number of ingredients: ");
        int numIngredients;
        while (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <= 0)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Invalid input. Please enter a valid positive integer: ");
            Console.ResetColor();
        }

        Ingredients.Clear();
        for (int i = 0; i < numIngredients; i++)
        {
            var ingredient = new Ingredient();

            Console.Write($"Name of ingredient {i + 1}: ");
            ingredient.Name = Console.ReadLine() ?? "";

            double quantity; // Declare quantity variable here
            Console.Write($"Quantity of ingredient {i + 1}: ");
            while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Invalid input. Please enter a valid positive number: ");
                Console.ResetColor();
            }
            ingredient.Quantity = ingredient.OriginalQuantity = quantity;

            Console.Write($"Unit of measurement for ingredient {i + 1}: ");
            ingredient.Unit = Console.ReadLine() ?? "";

            double calories; // Declare calories variable here
            Console.Write($"Calories for ingredient {i + 1}: ");
            while (!double.TryParse(Console.ReadLine(), out calories) || calories < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Invalid input. Please enter a valid non-negative number: ");
                Console.ResetColor();
            }
            ingredient.Calories = calories;

            int foodGroupIndex;
            Console.Write($"Food group for ingredient {i + 1} (0-Starchy Foods, 1-Vegetables and Fruits, 2-Dry Beans, Peas, Lentils and Soya, 3-Chicken, Fish, Meat and Eggs, 4-Milk and Dairy Products, 5-Fats and Oil, 6-Water): ");
            while (!int.TryParse(Console.ReadLine(), out foodGroupIndex) || !Enum.IsDefined(typeof(FoodGroup), foodGroupIndex))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Invalid input. Please enter a valid number for the food group: ");
                Console.ResetColor();
            }
            ingredient.FoodGroup = (FoodGroup)foodGroupIndex;

            Ingredients.Add(ingredient);
        }

        Console.Write("Number of steps: ");
        int numSteps;
        while (!int.TryParse(Console.ReadLine(), out numSteps) || numSteps <= 0)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Invalid input. Please enter a valid positive integer: ");
            Console.ResetColor();
        }

        Steps.Clear();
        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Step {i + 1}: ");
            Steps.Add(Console.ReadLine() ?? "");
        }

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Recipe entered successfully.");
        Console.ResetColor();

        double totalCalories = CalculateTotalCalories();
        Console.WriteLine($"Total Calories: {totalCalories}");

        if (totalCalories > 300)
        {
            CalorieNotification?.Invoke("Warning: The total calories of this recipe exceed 300. Calories measure the energy supplied by food and drinks.");
        }

        Display();
    }

    public void Display()
    {
        Console.WriteLine(new string('-', 30)); // Line at the bottom of the recipe
        Console.WriteLine("\nRecipe: " + string.Join(", ", Name));

        Console.WriteLine("\nIngredients:");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
        }
        Console.WriteLine($"Total Calories: {CalculateTotalCalories()}");

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {Steps[i]}");
        }
        Console.WriteLine(new string('-', 30)); // Line at the bottom of the recipe
    }

    public void ScaleRecipe()
    {
        if (!Ingredients.Any())
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nError: No recipe entered yet. Please enter a recipe first.");
            Console.ResetColor();
            return;
        }

        Console.Write("\nEnter scaling factor (0.5, 2, or 3): ");
        double factor;
        while (!double.TryParse(Console.ReadLine(), out factor) || (factor != 0.5 && factor != 2 && factor != 3))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Invalid input. Please enter a valid scaling factor (0.5, 2, or 3): ");
            Console.ResetColor();
        }

        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity = ingredient.OriginalQuantity * factor;
        }

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Recipe scaled successfully.");
        Console.ResetColor();

        double totalCalories = CalculateTotalCalories();
        Console.WriteLine($"Total Calories: {totalCalories}");

        if (totalCalories > 300)
        {
            CalorieNotification?.Invoke("Warning: The total calories of this recipe exceed 300. Calories measure the energy supplied by food and drinks.");
        }

        Display();
    }

    public void ResetQuantities()
    {
        if (!Ingredients.Any())
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nError: No recipe entered yet. Please enter a recipe first.");
            Console.ResetColor();
            return;
        }

        // Reset quantities to original values
        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity = ingredient.OriginalQuantity;
        }

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Quantities reset to original values.");
        Console.ResetColor();
        Display();
    }

    public void ClearRecipeData()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("\nAre you sure you want to clear recipe data? (yes/no): ");
        string confirm = Console.ReadLine()?.ToLower() ?? "";

        if (confirm == "yes")
        {
            Name.Clear();
            Ingredients.Clear();
            Steps.Clear();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Recipe data cleared.");
        }
        else if (confirm == "no")
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Operation canceled. Recipe data not cleared.");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Invalid input. Please enter 'yes' or 'no'.");
        }

        Console.ResetColor();
    }

    public double CalculateTotalCalories()
    {
        double totalCalories = Ingredients.Sum(ingredient => ingredient.Calories * ingredient.Quantity / ingredient.OriginalQuantity);
        Console.WriteLine("Calories measure the energy supplied by food and drinks.");
        return totalCalories;
    }
}
