﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_Prog2A_RecipeApp
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Collections.Generic;

    namespace RecipeApp.Tests
    {
        [TestClass]
        public class RecipeTests
        {
            [TestMethod]
            public void CalculateTotalCalories_ShouldReturnCorrectTotal()
            {
                // Arrange
                var recipe = new Recipe();
                recipe.Ingredients.Add(new Ingredient { Name = "Sugar", Quantity = 100, OriginalQuantity = 100, Calories = 400, Unit = "grams", FoodGroup = FoodGroup.FatsAndOil });
                recipe.Ingredients.Add(new Ingredient { Name = "Butter", Quantity = 50, OriginalQuantity = 50, Calories = 300, Unit = "grams", FoodGroup = FoodGroup.FatsAndOil });

                // Act
                var totalCalories = recipe.CalculateTotalCalories();

                // Assert
                Assert.AreEqual(700, totalCalories, "The total calories should be 700.");
            }
        }
    }
}
