﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Welcome to the Recipe App!");
        Console.ResetColor();

        var recipes = new List<Recipe>();

        while (true)
        {
            Console.WriteLine(new string('-', 30)); // Line at the top of the menu
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Menu:");
            Console.ForegroundColor = ConsoleColor.Cyan; // Change color for each option
            Console.WriteLine("1. Enter recipe");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("2. Scale recipe");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("3. Reset quantities");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("4. Clear recipe data");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("5. List all recipes");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("6. Exit");
            Console.ResetColor();
            Console.WriteLine(new string('-', 30)); // Line at the bottom of the menu
            Console.Write("\nEnter your choice: ");
            string? choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    var recipe = new Recipe();
                    recipe.CalorieNotification += message => Console.WriteLine(message);
                    recipe.EnterRecipe();
                    recipes.Add(recipe);
                    break;
                case "2":
                    if (!recipes.Any())
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("No recipes available. Please enter a recipe first.");
                        Console.ResetColor();
                        break;
                    }

                    Console.WriteLine("Select a recipe to scale:");
                    for (int i = 0; i < recipes.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {string.Join(", ", recipes[i].Name)}");
                    }

                    int scaleChoice;
                    while (!int.TryParse(Console.ReadLine(), out scaleChoice) || scaleChoice < 1 || scaleChoice > recipes.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. Please enter a valid recipe number.");
                        Console.ResetColor();
                    }

                    recipes[scaleChoice - 1].ScaleRecipe();
                    break;
                case "3":
                    if (!recipes.Any())
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("No recipes available. Please enter a recipe first.");
                        Console.ResetColor();
                        break;
                    }

                    Console.WriteLine("Select a recipe to reset quantities:");
                    for (int i = 0; i < recipes.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {string.Join(", ", recipes[i].Name)}");
                    }

                    int resetChoice;
                    while (!int.TryParse(Console.ReadLine(), out resetChoice) || resetChoice < 1 || resetChoice > recipes.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. Please enter a valid recipe number.");
                        Console.ResetColor();
                    }

                    recipes[resetChoice - 1].ResetQuantities();
                    break;
                case "4":
                    if (!recipes.Any())
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("No recipes available to clear.");
                        Console.ResetColor();
                        break;
                    }

                    Console.WriteLine("Select a recipe to clear:");
                    for (int i = 0; i < recipes.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {string.Join(", ", recipes[i].Name)}");
                    }

                    int clearChoice;
                    while (!int.TryParse(Console.ReadLine(), out clearChoice) || clearChoice < 1 || clearChoice > recipes.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. Please enter a valid recipe number.");
                        Console.ResetColor();
                    }

                    recipes[clearChoice - 1].ClearRecipeData();
                    recipes.RemoveAt(clearChoice - 1);
                    break;
                case "5":
                    if (!recipes.Any())
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("No recipes available.");
                        Console.ResetColor();
                        break;
                    }

                    Console.WriteLine("Recipes:");
                    foreach (var r in recipes.OrderBy(r => string.Join(", ", r.Name)))
                    {
                        Console.WriteLine(string.Join(", ", r.Name));
                    }

                    Console.WriteLine("Select a recipe to display:");
                    var recipeNames = recipes.OrderBy(r => string.Join(", ", r.Name)).Select(r => r.Name).ToList();
                    for (int i = 0; i < recipeNames.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {string.Join(", ", recipeNames[i])}");
                    }

                    int displayChoice;
                    while (!int.TryParse(Console.ReadLine(), out displayChoice) || displayChoice < 1 || displayChoice > recipeNames.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. Please enter a valid recipe number.");
                        Console.ResetColor();
                    }

                    recipes.First(r => r.Name.SequenceEqual(recipeNames[displayChoice - 1])).Display();
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nInvalid choice. Please enter a number between 1 and 6.");
                    Console.ResetColor();
                    break;
            }
        }
    }
}
